import { html } from "../../node_modules/lit-html/lit-html.js";

export let editTemplate = (form) => html`
<!-- Edit Page ( Only for the creator )-->
<section id="edit-page" class="auth">
    <form id="edit" @submit=${form.submitHandler}>
        <div class="container">

            <h1>Edit Game</h1>
            <label for="leg-title">Legendary title:</label>
            <input type="text" id="title" name="title" .value=${form.values.title}>

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" .value=${form.values.category}>

            <label for="levels">MaxLevel:</label>
            <input type="number" id="maxLevel" name="maxLevel" min="1" .value=${form.values.maxLevel}>

            <label for="game-img">Image:</label>
            <input type="text" id="imageUrl" name="imageUrl" .value=${form.values.imageUrl}>

            <label for="summary">Summary:</label>
            <textarea name="summary" id="summary">${form.values.summary}</textarea>
            <input class="btn submit" type="submit" value="Edit Game">

        </div>
    </form>
</section>
`